<div>
<h1>About </h1>
<p>Toko Online Tanaman Hias </p>
<p>Jl Semarang , 024 12345678</p>
</div>