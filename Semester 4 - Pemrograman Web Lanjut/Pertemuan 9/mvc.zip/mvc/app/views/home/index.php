<div>
<h1>Home </h1>
<p>Selamat Datang di Toko Online</p>
</div>