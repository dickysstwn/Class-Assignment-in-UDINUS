<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cart_model extends MY_Model 
{
    public $table = 'cart';     // Ini akan diubah2 di controller Cart
}

/* End of file Cart_model.php */
