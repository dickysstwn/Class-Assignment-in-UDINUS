<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Dashboard extends CI_Controller {
    //fungsi untuk menampilkan halaman toko
    public function index()
    { 
        $data['produk']=$this->model_produk->tampil_produk()->result();
        $this->load->view('template/header');//menampilkan halaman header(header.php) pada folder template di folder view
        $this->load->view('template/sidebar'); //menampilkan halaman sidebar(sidebar.php) pada folder template di folder view
        $this->load->view('dashboard',$data); //menampilkan halaman dashboard (dashboard.php)  di folder view dan menginclude $data pada dashboard.php
        $this->load->view('template/footer');//menampilkan halaman footer (footer.php) pada folder template di folder view
    }

    //fungsi untuk tambah item ke keranjang saat mengklik tombol tambah ke keranjang pada produk
    public function tambah_keranjang($id)
    {
        $produk = $this->model_produk->find($id); //meload fungsi find pada model model_produk.php

        $data = array(
                'id'      => $produk->id_brg,
                'qty'     => 1,
                'price'   => $produk->harga,
                'name'    => $produk->nm_brg,
                //'options' => array('Size' => 'L', 'Color' => 'Red')
        );
    
    $this->cart->insert($data); //memasukkan data ke dalam cart
    redirect('dashboard'); //redirect dashboard.php
    }

    public function tambah_keranjang_monitor($id)
    {
        $produk = $this->model_produk->find($id); //meload fungsi find pada model model_produk.php

        $data = array(
                'id'      => $produk->id_brg,
                'qty'     => 1,
                'price'   => $produk->harga,
                'name'    => $produk->nm_brg,
                //'options' => array('Size' => 'L', 'Color' => 'Red')
        );
    
    $this->cart->insert($data); //memasukkan data ke dalam cart
    redirect('merk/merk_monitor'); //redirect dashboard.php
    }

    public function tambah_keranjang_laptop($id)
    {
        $produk = $this->model_produk->find($id); //meload fungsi find pada model model_produk.php

        $data = array(
                'id'      => $produk->id_brg,
                'qty'     => 1,
                'price'   => $produk->harga,
                'name'    => $produk->nm_brg,
                //'options' => array('Size' => 'L', 'Color' => 'Red')
        );
    
    $this->cart->insert($data); //memasukkan data ke dalam cart
    redirect('merk/merk_laptop'); //redirect dashboard.php
    }

    public function tambah_keranjang_memory($id)
    {
        $produk = $this->model_produk->find($id); //meload fungsi find pada model model_produk.php

        $data = array(
                'id'      => $produk->id_brg,
                'qty'     => 1,
                'price'   => $produk->harga,
                'name'    => $produk->nm_brg,
                //'options' => array('Size' => 'L', 'Color' => 'Red')
        );
    
    $this->cart->insert($data); //memasukkan data ke dalam cart
    redirect('merk/merk_memory'); //redirect dashboard.php
    }

    public function tambah_keranjang_peripheral($id)
    {
        $produk = $this->model_produk->find($id); //meload fungsi find pada model model_produk.php

        $data = array(
                'id'      => $produk->id_brg,
                'qty'     => 1,
                'price'   => $produk->harga,
                'name'    => $produk->nm_brg,
                //'options' => array('Size' => 'L', 'Color' => 'Red')
        );
    
    $this->cart->insert($data); //memasukkan data ke dalam cart
    redirect('merk/merk_peripheral'); //redirect dashboard.php
    }

    public function tambah_keranjang_storage($id)
    {
        $produk = $this->model_produk->find($id); //meload fungsi find pada model model_produk.php

        $data = array(
                'id'      => $produk->id_brg,
                'qty'     => 1,
                'price'   => $produk->harga,
                'name'    => $produk->nm_brg,
                //'options' => array('Size' => 'L', 'Color' => 'Red')
        );
    
    $this->cart->insert($data); //memasukkan data ke dalam cart
    redirect('merk/merk_storage'); //redirect dashboard.php
    }

    public function tambah_keranjang_psu($id)
    {
        $produk = $this->model_produk->find($id); //meload fungsi find pada model model_produk.php

        $data = array(
                'id'      => $produk->id_brg,
                'qty'     => 1,
                'price'   => $produk->harga,
                'name'    => $produk->nm_brg,
                //'options' => array('Size' => 'L', 'Color' => 'Red')
        );
    
    $this->cart->insert($data); //memasukkan data ke dalam cart
    redirect('merk/merk_powersupply'); //redirect dashboard.php
    }
    
    //fungsi untuk mengetahui detail item yang dimasukan ke keranjang
    public function detail_keranjang()
    {
        $this->load->view('template/header'); //menampilkan halaman header(header.php) pada folder template di folder view
        $this->load->view('template/sidebar'); //menampilkan halaman sidebar(sidebar.php) pada folder template di folder view
        $this->load->view('keranjang'); //menampilkan halaman keranjang (keranjang.php)  di folder view 
        $this->load->view('template/footer'); //menampilkan halaman footer (footer.php) pada folder template di folder view
    }
    
    //fungsi untuk hapus keranjang
    public function hapus_keranjang()
    {
        $this->cart->destroy();
        redirect('dashboard/index'); //redirect fungsi index pada  dashboard.php 
    }

    //fungsi pembayaran
    public function pembayaran()
    {
        $this->load->view('template/header'); //menampilkan halaman header(header.php) pada folder template di folder view
        $this->load->view('template/sidebar'); //menampilkan halaman sidebar(sidebar.php) pada folder template di folder view
        $this->load->view('pembayaran'); //menampilkan halaman pembayaran (pembayaran.php)  di folder view 
        $this->load->view('template/footer');  //menampilkan halaman footer (footer.php) pada folder template di folder view
    } 

    //fungsi untuk proses pesanan
    public function proses_pesanan()
    {
        $proses = $this->model_jual->index(); //jika mengklik tombol bayar maka data pesanan dan data pelanggan akan masuk ke fungsi index() pada model_jual
        if($proses) 
        {
            $this->cart->destroy(); //jika pembayaran berhasil maka keranjang dikosongkan
            $this->load->view('template/header'); //menampilkan halaman header(header.php) pada folder template di folder view
            $this->load->view('template/sidebar'); //menampilkan halaman sidebar(sidebar.php) pada folder template di folder view
            $this->load->view('proses_pesanan');  //menampilkan halaman proses_pesanan (proses_pesanan .php)  di folder view 
            $this->load->view('template/footer'); //menampilkan halaman footer (footer.php) pada folder template di folder view
        }
        else
        {
            echo "Maaf Pesanan Anda gagal Diproses";
        }
       
    }
    
    //fungsi untuk menampilkan detail produk saat mengklik tombol detail pada produk
    public function detail($id_brg)
    { 
        $data['produk']=$this->model_produk->detail_prd($id_brg);  //meload fungsi detail_prd() pada model model_produk.php
        $this->load->view('template/header'); //menampilkan halaman header(header.php) pada folder template di folder view
        $this->load->view('template/sidebar'); //menampilkan halaman sidebar(sidebar.php) pada folder template di folder view
        $this->load->view('detail_barang',$data); //menampilkan halaman detail barang (detail_barang .php)  di folder view 
        $this->load->view('template/footer');  //menampilkan halaman footer (footer.php) pada folder template di folder view
    }


}