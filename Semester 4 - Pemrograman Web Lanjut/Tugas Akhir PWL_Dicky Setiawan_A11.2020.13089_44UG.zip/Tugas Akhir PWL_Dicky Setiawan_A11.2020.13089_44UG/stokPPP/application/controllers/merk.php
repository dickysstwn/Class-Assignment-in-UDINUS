<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Merk extends CI_Controller {

   public function merk_monitor(){
    $data['monitor']=$this->model_merk->monitor()->result();
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    $this->load->view('merk/monitor',$data);
    $this->load->view('template/footer');
   }

   public function merk_laptop(){
    $data['laptop']=$this->model_merk->laptop()->result();
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    $this->load->view('merk/laptop',$data);
    $this->load->view('template/footer');
   }

   public function merk_peripheral(){
    $data['peripheral']=$this->model_merk->peripheral()->result();
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    $this->load->view('merk/peripheral',$data);
    $this->load->view('template/footer');
   }

   public function merk_storage(){
      $data['storage']=$this->model_merk->storage()->result();
      $this->load->view('template/header');
      $this->load->view('template/sidebar');
      $this->load->view('merk/storage',$data);
      $this->load->view('template/footer');
     }

     public function merk_powersupply(){
      $data['psu']=$this->model_merk->power_supply()->result();
      $this->load->view('template/header');
      $this->load->view('template/sidebar');
      $this->load->view('merk/powersupply',$data);
      $this->load->view('template/footer');
     }

     public function merk_memory(){
      $data['ram']=$this->model_merk->ram()->result();
      $this->load->view('template/header');
      $this->load->view('template/sidebar');
      $this->load->view('merk/memory',$data);
      $this->load->view('template/footer');
     }

   public function cari(){
      $kunci          = $this->input->post('cari');
      $data['find']=$this->model_merk->cari($kunci);
      $this->load->view('template/header');
    $this->load->view('template/sidebar');
    $this->load->view('merk/ketemu',$data);
    $this->load->view('template/footer');

     }
  
}