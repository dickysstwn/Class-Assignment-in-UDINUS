<?php
require('cobafpdf/fpdf.php');
$pdf= new FPDF();
$pdf->Addpage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(40,10,'Hello World');
$pdf->Output();

?>