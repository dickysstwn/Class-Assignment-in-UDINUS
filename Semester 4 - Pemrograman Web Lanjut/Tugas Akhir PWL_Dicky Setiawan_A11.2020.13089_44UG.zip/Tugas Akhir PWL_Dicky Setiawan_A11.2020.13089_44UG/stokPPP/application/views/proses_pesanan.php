<div class="container-fluid">
    <div class="alert alert-success">
        <p class="text-center align-middle">
            Pesanan Anda Masuk !
        </p>
    </div>
</div>