<div class="container-fluid">
    <h4>Rekap Pemesanan Produk</h4>
    <button class="btn btn-sm btn-success mb-3" data-toggle="modal" ><a href="<?php echo base_url('admin/jual/Data_Jual') ?>"> Laporan Data Pesanan </a> </button>
    <table class="table table-bordered table-striped table-hover">
        <tr>
            <th>Id Rekap</th>
            <th>Nama Pemesan</th>
            <th>Tim</th>
            <th>Tanggal Pemesanan</th>
            <th>Aksi</th>
            <th>Laporan</th>
        </tr>
       
            <?php foreach ($jual as $jl): ?>
                <tr>
                    <td>
                        <?php echo $jl->id ?>
                    </td>
                    <td>
                        <?php echo $jl->nama ?>
                    </td>
                    <td>
                        <?php echo $jl->alamat ?>
                    </td>
                    <td>
                        <?php echo $jl->tgl_pesan ?>
                    </td>
                    <td>  <?php echo anchor('admin/jual/detail/'.$jl->id,'<div class="btn btn-sm btn-primary">Detail</div>')?></td>
                    <td>  <?php echo anchor('admin/jual/Data_Pesanan/'.$jl->id,'<div class="btn btn-sm btn-primary">Laporan</div>')?></td>
                    
                </tr>
            <?php endforeach; ?>

        
    </table>
</div>