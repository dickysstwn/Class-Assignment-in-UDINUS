<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Model_merk extends CI_Model {
    public function monitor(){
        return $this->db->get_where('tb_brg',array('merk'=>'MONITOR'));
    }
    public function laptop(){
        return $this->db->get_where('tb_brg',array('merk'=>'LAPTOP'));
    }

    public function peripheral(){
        return $this->db->get_where('tb_brg',array('merk'=>'PERIPHERAL'));
    }

    public function storage(){
        return $this->db->get_where('tb_brg',array('merk'=>'STORAGE'));
    }

    public function ram(){
        return $this->db->get_where('tb_brg',array('merk'=>'RAM'));
    }

    public function power_supply(){
        return $this->db->get_where('tb_brg',array('merk'=>'PSU'));
    }

    public function cari($kunci){
        $this->db->select('*');
        $this->db->from('tb_brg');
        $this->db->like('nm_brg',$kunci);
        $this->db->or_like('harga',$kunci);
        return $this->db->get()->result();
    }
}